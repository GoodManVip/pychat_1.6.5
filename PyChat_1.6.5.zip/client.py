import socket, threading, time,random
#import colorama

key = 8194

shutdown = False
join = False

print("WELCOME TO PyChat")
print(" _______              ______   __                    __     ")
print("/       \            /      \ /  |                  /  |    ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_   ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |  ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/   ")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/ ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/  ")
print("          /  \__$$ |  ")                                      
print("          $$    $$/  ")                                       
print("           $$$$$$/")                                          
print("By: Tikhon Sherstobitov")
class mesh():
    def gen(level,abcg):
        i=0
        m=""
        while not level == i:
            m = m+abcg[random.randint(1,len(abcg))-1]
            i+=1
        return m
def receving (name, sock):
        while not shutdown:
                try:
                        while True:
                                data, addr = sock.recvfrom(1024)
                                #print(data.decode("utf-8"))

                                # Begin
                                decrypt = ""; k = False
                                for i in data.decode("utf-8"):
                                        if i == ":":
                                                k = True
                                                decrypt += i
                                        elif k == False or i == " ":
                                                decrypt += i
                                        else:
                                                decrypt += chr(ord(i)^key)
                                if data.decode("utf-8") == '/banned':
                                     print('You has banned on this server!')
                                     rT.join()
                                     s.close()
                                     exit()
                                print(data.decode('utf-8'))
                                # End

                                time.sleep(0.2)
                except:
                        pass
host = socket.gethostbyname(socket.gethostname())
port = 0

getip = ""
getport = ""
'''
ct=input("Custom setings/Standart setings(Only for test!)?:")

if ct == "Custom setings":
        print("test ip = 127.0.1.1")
        getip = input("server IP = ")
        print("test port = 9090")
        getport = input("Server Pprt = ")
if ct == "Standart setings":
        getip = "127.0.1.1"
        getport = 9090
server = (str(getip),int(getport))
'''
count = 1
server_list = open('server.txt')
for server in server_list.readlines():
        print(str(count)+'. Name: '+server.split('=')[0]+' Ip:'+server.split('=')[1]+' Port:'+server.split('=')[2])
        count=count+1
ct = input('Serer:')
getip = server.split('=')[1]
getport = server.split('=')[2]
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
s.setblocking(0)
print('Conected!')

aliasl = input("Name: ")
alias='(*)['+aliasl+']'

server = (str(getip),int(getport))

rT = threading.Thread(target = receving, args = ("RecvThread",s))
rT.start()

ids=mesh.gen(10,'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890')
exp=0
while shutdown == False:
        if join == False:
                s.sendto((alias + " => join chat ").encode("utf-8"),server)
                join = True
        else:
                try:
                        message = input()
                        try:
                            if message.split(':')[0] == '/say':
                                    oldalias=alias
                                    alias='WARNING'
                                    a=("!"+alias + "! :: "+message.split(':')[1]).encode("utf-8")
                                    s.sendto(a,server)
                                    alias=oldalias
                            elif message.split(':')[0] == '/rules':
                                    a=open('rules.txt')
                                    print(a.read())
                                    a.close()
                            elif message.split(':')[0] == '/getuuid':
                                    print('Sesion uuid:'+str(ids))

                            else:
                                if message!="":
                                    a=(alias + " :: "+message).encode("utf-8")
                                    s.sendto(a,server)
                                    exp+=1
                                    #print(str(exp))
                                if int(exp) == 50:
                                    alias='(V.I.P)['+aliasl+']'
                                    print('You reached VIP status!')
                                if exp == 250:
                                    #print('You reached SUPER status')
                                    alias='(Super)['+aliasl+']'
                                if exp==500:
                                    alias='(Gold)['+aliasl+']'
                                    #print('You reached GOLD status!')
                        except:
                                pass
                                #print(IOexception)
                            #if message!="":
                            #    a=("["+alias + "] :: "+message).encode("utf-8")
                            #    s.sendto(a,server)
                        time.sleep(0.2)
                except:
                        s.sendto((alias + " <= left chat ").encode("utf-8"),server)
                        shutdown = True

rT.join()
s.close()
